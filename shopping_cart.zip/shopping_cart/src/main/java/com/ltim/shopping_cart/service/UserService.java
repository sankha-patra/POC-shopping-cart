package com.ltim.shopping_cart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltim.shopping_cart.config.UserInfoUserDetails;
import com.ltim.shopping_cart.entity.Cart;
import com.ltim.shopping_cart.entity.User;
import com.ltim.shopping_cart.repository.CartRepository;
import com.ltim.shopping_cart.repository.UserRepository;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;



@Service
public class UserService implements UserDetailsService{


    @Autowired
    private UserRepository userRepository;
    @Autowired
    private  CartRepository cartRepository;
    @Autowired
    PasswordEncoder encoder;


    public User registerUser(User user) {
        Optional<User> existingUser = userRepository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
          return null; 
        } else {
            user.setPassword(encoder.encode(user.getPassword()));

            // add cart during registration only if the role is client
            if ("CLIENT".equals(user.getRole())) {
              Cart newCart = new Cart();
              newCart.setUser(user); 
              cartRepository.save(newCart);
            }
           
           

            return userRepository.save(user);
        }
      }

    public User getUserByUsername(String username) {
      
      return userRepository.findByUsername(username).get();
    }
    public List<User> getAllClients(){
     
      // return users where role is CLIENT

       List<User> allUsers = userRepository.findAll();
    List<User> clientUsers = new ArrayList<>();

    for (User user : allUsers) {
        if ("CLIENT".equals(user.getRole())) {
            clientUsers.add(user);
        }
    }

    return clientUsers;
      
    }
    public User updateUser(Long userId, User user){
     
      return userRepository.save(user);
    }

     @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findByUsername(username);
        return user.map(UserInfoUserDetails::new)
                    .orElseThrow(() -> new UsernameNotFoundException("user not found " + username));
    }

    public User getUserById(long userId) {
      return userRepository.findById(userId).orElse(null);
   }

   public boolean deleteClient(Long userId){
    User user=userRepository.getById(userId);
    if(user!=null && "CLIENT".equals(user.getRole())){
      userRepository.deleteById(userId);
      return true;
    }
    else{
      return false;
    }
   }


    
}

