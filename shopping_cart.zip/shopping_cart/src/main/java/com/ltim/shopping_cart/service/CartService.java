package com.ltim.shopping_cart.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltim.shopping_cart.entity.Cart;
import com.ltim.shopping_cart.entity.Product;
import com.ltim.shopping_cart.entity.User;
import com.ltim.shopping_cart.repository.CartRepository;
import com.ltim.shopping_cart.repository.ProductRepository;
import com.ltim.shopping_cart.repository.UserRepository;

@Service
public class CartService {
    
    @Autowired
    private  UserRepository userRepository;
    @Autowired
    private  ProductRepository productRepository;
    @Autowired
    private CartRepository cartRepository; 

    public boolean addToCart(Long userId, Long productId) {
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Product> productOptional = productRepository.findById(productId);

        if (userOptional.isPresent() && productOptional.isPresent()) {
            User user = userOptional.get();
            Product product = productOptional.get();

            // Adding the product to the user's cart
            user.getCart().getProductsInCart().add(product);
            userRepository.save(user);

            return true;
        }

        return false; // Return false if user or product is not found
    }

     public List<Product> getProductsInCartByUsername(String username) {

        // Retrieving the cart entity associated with the given user name
        Cart cart = cartRepository.findCartByUsername(username);

        if (cart != null) {
        
            Set<Product> productsInCart = cart.getProductsInCart();
           
            return new ArrayList<>(productsInCart);
        } else {
            // if no cart is found for the given user name return null
          
            return Collections.emptyList();
        }
    }

    public Cart createOrUpdateCartForUser(User user) {

        // Check if the user already has a cart
        Cart existingCart = user.getCart();
        if (existingCart != null) {
            
            return cartRepository.save(existingCart);
        } else {
           
            Cart newCart = new Cart();
            newCart.setUser(user); 
            return cartRepository.save(newCart);
        }
    }

    
   
}
